<?php
/**
 * Plugin Name: WebPrinter Engine
 * Plugin URI:  https://webprinter.io
 * Description: Contractor website generator. Exposes a REST endpoint to build complete Elementor-based sites from contractor JSON data.
 * Version:     1.0.0
 * Author:      WebPrinter
 * License:     GPL-2.0+
 *
 * @package WebPrinter
 */

defined('ABSPATH') || exit;

define('WEBPRINTER_DIR', plugin_dir_path(__FILE__));

require_once WEBPRINTER_DIR . 'elementor-header-footer-injector.php';
require_once WEBPRINTER_DIR . 'elementor-about-injector.php';
require_once WEBPRINTER_DIR . 'elementor-services-injector.php';
require_once WEBPRINTER_DIR . 'elementor-estimate-injector.php';
require_once WEBPRINTER_DIR . 'elementor-contact-injector.php';
require_once WEBPRINTER_DIR . 'contractor-schema-generator.php';

add_action('rest_api_init', 'webprinter_register_routes');

function webprinter_register_routes() {
    register_rest_route('webprinter/v1', '/generate', [
        'methods'             => 'POST',
        'callback'            => 'webprinter_handle_generate',
        'permission_callback' => 'webprinter_check_permission',
        'args'                => webprinter_route_args(),
    ]);
}

function webprinter_check_permission(WP_REST_Request $request) {
    $secret = get_option('webprinter_api_secret', '');
    if ($secret !== '') {
        $provided = $request->get_header('X-Webprinter-Secret');
        if ($provided !== $secret) {
            return new WP_Error('forbidden', 'Invalid API secret.', ['status' => 403]);
        }
    }
    return true;
}

function webprinter_route_args() {
    $string_field = ['type' => 'string', 'sanitize_callback' => 'sanitize_text_field'];
    return [
        'company_name'  => array_merge($string_field, ['required' => true]),
        'trade'         => array_merge($string_field, ['required' => true]),
        'city'          => array_merge($string_field, ['required' => true]),
        'state'         => array_merge($string_field, ['required' => true]),
        'phone'         => array_merge($string_field, ['required' => true]),
        'email'         => ['type' => 'string', 'required' => true, 'sanitize_callback' => 'sanitize_email'],
        'website'       => $string_field,
        'tagline'       => $string_field,
        'hero_headline' => $string_field,
        'about'         => ['type' => 'string', 'sanitize_callback' => 'wp_kses_post'],
        'service_1_desc' => $string_field,
        'service_2_desc' => $string_field,
        'service_3_desc' => $string_field,
        'service_4_desc' => $string_field,
    ];
}

function webprinter_handle_generate(WP_REST_Request $request) {
    $params = $request->get_params();

    $company  = $params['company_name'];
    $trade    = $params['trade'];
    $city     = $params['city'];
    $state    = $params['state'];
    $phone    = $params['phone'];
    $email    = $params['email'];
    $website  = $params['website']       ?? site_url();
    $tagline  = $params['tagline']       ?? "Professional {$trade} Services in {$city}";
    $headline = $params['hero_headline'] ?? "Trusted {$trade} Services in {$city}, {$state}";
    $about    = $params['about']         ?? "We are {$company}, providing quality {$trade} services in {$city}.";

    $services = [
        ['name' => ucfirst($trade) . ' Service 1', 'description' => $params['service_1_desc'] ?? "Expert {$trade} service for your home or business."],
        ['name' => ucfirst($trade) . ' Service 2', 'description' => $params['service_2_desc'] ?? "Reliable {$trade} solutions at competitive prices."],
        ['name' => ucfirst($trade) . ' Service 3', 'description' => $params['service_3_desc'] ?? "Professional {$trade} work guaranteed."],
        ['name' => ucfirst($trade) . ' Service 4', 'description' => $params['service_4_desc'] ?? "Fast and efficient {$trade} service."],
    ];

    $base = [
        'company_name' => $company,
        'trade'        => $trade,
        'city'         => $city,
        'state'        => $state,
        'phone'        => $phone,
        'email'        => $email,
        'website'      => $website,
        'tagline'      => $tagline,
        'hero_headline' => $headline,
        'about'        => $about,
        'services'     => $services,
    ];

    $schema_html = generate_contractor_schema([
        'name'    => $company,
        'trade'   => $trade,
        'phone'   => $phone,
        'email'   => $email,
        'address' => "{$city}, {$state}",
        'city'    => $city,
        'state'   => $state,
        'website' => $website,
        'services' => array_column($services, 'name'),
    ]);

    $pages_config = [
        'home' => [
            'title' => $company . ' – Home',
            'slug'  => 'home',
            'json'  => build_about_elementor_json(array_merge($base, [
                'hero_headline' => $headline,
                'hero_sub'      => "Serving {$city}, {$state} and surrounding areas",
            ])),
        ],
        'about' => [
            'title' => 'About ' . $company,
            'slug'  => 'about',
            'json'  => build_about_elementor_json($base),
        ],
        'services' => [
            'title' => $company . ' Services',
            'slug'  => 'services',
            'json'  => build_services_elementor_json($base),
        ],
        'estimate' => [
            'title' => 'Get a Free Estimate',
            'slug'  => 'estimate',
            'json'  => build_estimate_elementor_json($base),
        ],
        'contact' => [
            'title' => 'Contact ' . $company,
            'slug'  => 'contact',
            'json'  => build_contact_elementor_json($base),
        ],
    ];

    $urls = [];

    foreach ($pages_config as $key => $cfg) {
        $post_id = webprinter_upsert_page($cfg['title'], $cfg['slug']);

        if (is_wp_error($post_id)) {
            return new WP_Error('page_create_failed', "Failed to create page: {$cfg['title']}", ['status' => 500]);
        }

        update_post_meta($post_id, '_elementor_edit_mode',    'builder');
        update_post_meta($post_id, '_elementor_template_type', 'wp-page');
        update_post_meta($post_id, '_elementor_version',      '3.0.0');
        update_post_meta($post_id, '_elementor_data',         $cfg['json']);

        if ($key === 'home') {
            $existing_schema = get_post_meta($post_id, '_webprinter_schema', true);
            if ($existing_schema !== $schema_html) {
                update_post_meta($post_id, '_webprinter_schema', $schema_html);
            }

            update_option('page_on_front', $post_id);
            update_option('show_on_front', 'page');
        }

        $urls[$key] = get_permalink($post_id);
    }

    return rest_ensure_response([
        'success' => true,
        'urls'    => $urls,
    ]);
}

function webprinter_upsert_page($title, $slug) {
    $existing = get_page_by_path($slug, OBJECT, 'page');

    $post_data = [
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_content' => '',
        'page_template' => 'elementor_canvas',
    ];

    if ($existing) {
        $post_data['ID'] = $existing->ID;
        return wp_update_post($post_data, true);
    }

    return wp_insert_post($post_data, true);
}
