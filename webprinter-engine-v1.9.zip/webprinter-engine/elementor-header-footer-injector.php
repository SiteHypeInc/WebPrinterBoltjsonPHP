<?php
/**
 * Elementor Header/Footer Injector
 *
 * Injects contractor data into Elementor header and footer JSON templates.
 * If a raw JSON string is supplied it performs placeholder replacement.
 * If null is supplied it generates a minimal, functional template from scratch.
 *
 * Exported functions:
 *   inject_header_data( string|null $json, array $data ) : string
 *   inject_footer_data( string|null $json, array $data ) : string
 *   build_header_elementor_json( array $data )            : string  (used by plugin)
 *   build_footer_elementor_json( array $data )            : string  (used by plugin)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

function inject_header_data($json, array $data) {
    if (empty($json)) {
        return build_header_elementor_json($data);
    }

    $replacements = [
        '{{COMPANY_NAME}}' => $data['name']    ?? '',
        '{{PHONE}}'        => $data['phone']   ?? '',
        '{{EMAIL}}'        => $data['email']   ?? '',
        '{{LOGO_URL}}'     => $data['logo_url'] ?? '',
        '{{TAGLINE}}'      => $data['tagline'] ?? '',
    ];

    return str_replace(array_keys($replacements), array_values($replacements), $json);
}

function inject_footer_data($json, array $data) {
    if (empty($json)) {
        return build_footer_elementor_json($data);
    }

    $address = $data['address'] ?? implode(', ', array_filter([
        $data['city']  ?? '',
        $data['state'] ?? '',
        $data['zip']   ?? '',
    ]));

    $replacements = [
        '{{COMPANY_NAME}}' => $data['name']     ?? '',
        '{{PHONE}}'        => $data['phone']    ?? '',
        '{{EMAIL}}'        => $data['email']    ?? '',
        '{{ADDRESS}}'      => $address,
        '{{CITY}}'         => $data['city']     ?? '',
        '{{STATE}}'        => $data['state']    ?? '',
        '{{ZIP}}'          => $data['zip']      ?? '',
        '{{TAGLINE}}'      => $data['tagline']  ?? '',
        '{{LICENSE}}'      => $data['license']  ?? 'Licensed & Insured',
        '{{FACEBOOK}}'     => $data['facebook'] ?? '',
        '{{TWITTER}}'      => $data['twitter']  ?? '',
        '{{INSTAGRAM}}'    => $data['instagram'] ?? '',
        '{{LINKEDIN}}'     => $data['linkedin'] ?? '',
    ];

    return str_replace(array_keys($replacements), array_values($replacements), $json);
}

function build_header_elementor_json(array $data) {
    $name    = esc_attr($data['company_name'] ?? $data['name'] ?? '');
    $phone   = esc_attr($data['phone'] ?? '');
    $tagline = esc_attr($data['tagline'] ?? '');
    $logo    = esc_url($data['logo_url'] ?? '');

    $nav_html = '<nav class="wp-nav"><a href="/">Home</a> | <a href="/about">About</a> | <a href="/services">Services</a> | <a href="/estimate">Estimate</a> | <a href="/contact">Contact</a></nav>';

    $logo_widget = $logo
        ? webprinter_image_widget('hdr-logo', $logo, $name)
        : webprinter_heading_widget('hdr-name', $name, 'h1');

    $template = [
        webprinter_section('hdr-section', [
            webprinter_column('hdr-col-logo', 33, [$logo_widget]),
            webprinter_column('hdr-col-nav',  50, [webprinter_html_widget('hdr-nav', $nav_html)]),
            webprinter_column('hdr-col-phone', 17, [
                webprinter_heading_widget('hdr-phone', $phone, 'h3'),
                webprinter_text_widget('hdr-tagline', $tagline),
            ]),
        ], ['background_color' => '#1a1a2e', 'padding' => ['top' => '20', 'bottom' => '20']]),
    ];

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

function build_footer_elementor_json(array $data) {
    $name    = esc_attr($data['company_name'] ?? $data['name'] ?? '');
    $phone   = esc_attr($data['phone'] ?? '');
    $email   = esc_attr($data['email'] ?? '');
    $tagline = esc_attr($data['tagline'] ?? '');
    $city    = esc_attr($data['city'] ?? '');
    $state   = esc_attr($data['state'] ?? '');
    $address = esc_attr($data['address'] ?? "{$city}, {$state}");
    $year    = date('Y');

    $template = [
        webprinter_section('ftr-section', [
            webprinter_column('ftr-col-brand', 33, [
                webprinter_heading_widget('ftr-name', $name, 'h3'),
                webprinter_text_widget('ftr-tagline', $tagline),
            ]),
            webprinter_column('ftr-col-contact', 33, [
                webprinter_heading_widget('ftr-contact-h', 'Contact Us', 'h4'),
                webprinter_text_widget('ftr-phone', "Phone: {$phone}"),
                webprinter_text_widget('ftr-email', "Email: {$email}"),
                webprinter_text_widget('ftr-address', $address),
            ]),
            webprinter_column('ftr-col-links', 33, [
                webprinter_heading_widget('ftr-links-h', 'Quick Links', 'h4'),
                webprinter_html_widget('ftr-links', '<ul><li><a href="/about">About</a></li><li><a href="/services">Services</a></li><li><a href="/estimate">Free Estimate</a></li><li><a href="/contact">Contact</a></li></ul>'),
            ]),
        ], ['background_color' => '#1a1a2e', 'padding' => ['top' => '40', 'bottom' => '20']]),
        webprinter_section('ftr-copy', [
            webprinter_column('ftr-copy-col', 100, [
                webprinter_text_widget('ftr-copyright', "&copy; {$year} {$name}. All rights reserved."),
            ]),
        ], ['background_color' => '#0f0f1a', 'padding' => ['top' => '15', 'bottom' => '15']]),
    ];

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}

/* -----------------------------------------------------------------------
 * Shared Elementor element builder helpers
 * Used by all injector files — defined here to avoid redeclaration.
 * ----------------------------------------------------------------------- */

if (!function_exists('webprinter_uid')) {
    function webprinter_uid($seed = '') {
        return substr(md5($seed . microtime()), 0, 8);
    }
}

if (!function_exists('webprinter_section')) {
    function webprinter_section($id, array $columns, array $settings = []) {
        return [
            'id'       => $id,
            'elType'   => 'section',
            'settings' => $settings,
            'elements' => $columns,
        ];
    }
}

if (!function_exists('webprinter_column')) {
    function webprinter_column($id, $width, array $widgets) {
        return [
            'id'       => $id,
            'elType'   => 'column',
            'settings' => ['_column_size' => $width],
            'elements' => $widgets,
        ];
    }
}

if (!function_exists('webprinter_heading_widget')) {
    function webprinter_heading_widget($id, $text, $tag = 'h2', array $extra = []) {
        return array_merge([
            'id'         => $id,
            'elType'     => 'widget',
            'widgetType' => 'heading',
            'settings'   => ['title' => $text, 'header_size' => $tag],
            'elements'   => [],
        ], $extra);
    }
}

if (!function_exists('webprinter_text_widget')) {
    function webprinter_text_widget($id, $text, array $extra = []) {
        return array_merge([
            'id'         => $id,
            'elType'     => 'widget',
            'widgetType' => 'text-editor',
            'settings'   => ['editor' => $text],
            'elements'   => [],
        ], $extra);
    }
}

if (!function_exists('webprinter_html_widget')) {
    function webprinter_html_widget($id, $html, array $extra = []) {
        return array_merge([
            'id'         => $id,
            'elType'     => 'widget',
            'widgetType' => 'html',
            'settings'   => ['html' => $html],
            'elements'   => [],
        ], $extra);
    }
}

if (!function_exists('webprinter_image_widget')) {
    function webprinter_image_widget($id, $url, $alt = '', array $extra = []) {
        return array_merge([
            'id'         => $id,
            'elType'     => 'widget',
            'widgetType' => 'image',
            'settings'   => [
                'image' => ['url' => $url, 'alt' => $alt],
                'link_to' => 'custom',
                'link'   => ['url' => '/'],
            ],
            'elements' => [],
        ], $extra);
    }
}

if (!function_exists('webprinter_button_widget')) {
    function webprinter_button_widget($id, $text, $url = '#', $style = 'default', array $extra = []) {
        return array_merge([
            'id'         => $id,
            'elType'     => 'widget',
            'widgetType' => 'button',
            'settings'   => [
                'text'         => $text,
                'link'         => ['url' => $url],
                'button_type'  => $style,
            ],
            'elements' => [],
        ], $extra);
    }
}
