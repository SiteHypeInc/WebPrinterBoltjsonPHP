<?php
/**
 * Elementor Contact Page Injector
 *
 * Injects contractor data into the Contact page Elementor template.
 *
 * Exported functions:
 *   inject_contact_data( array|null $template, array $data ) : array
 *   build_contact_elementor_json( array $data )              : string  (used by plugin)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

require_once __DIR__ . '/elementor-header-footer-injector.php';

function inject_contact_data($template, array $data) {
    if (empty($template)) {
        return json_decode(build_contact_elementor_json($data), true);
    }

    $replacements = [
        '{{COMPANY_NAME}}'    => $data['name']             ?? '',
        '{{PHONE}}'           => $data['phone']            ?? '',
        '{{EMAIL}}'           => $data['email']            ?? '',
        '{{ADDRESS}}'         => $data['address']          ?? '',
        '{{HOURS}}'           => $data['hours']            ?? 'Mon-Fri: 8am-5pm',
        '{{EMERGENCY_PHONE}}' => $data['emergency_phone']  ?? $data['phone'] ?? '',
    ];

    $json = json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $json = str_replace(array_keys($replacements), array_values($replacements), $json);
    return json_decode($json, true);
}

function build_contact_elementor_json(array $data) {
    $name      = $data['company_name'] ?? $data['name'] ?? '';
    $phone     = $data['phone']    ?? '';
    $email     = $data['email']    ?? '';
    $city      = $data['city']     ?? '';
    $state     = $data['state']    ?? '';
    $address   = $data['address']  ?? "{$city}, {$state}";
    $hours     = $data['hours']    ?? 'Mon–Fri: 8:00am – 5:00pm';
    $emergency = !empty($data['emergency']);
    $emrg_phone = $data['emergency_phone'] ?? $phone;

    $contact_form_html = <<<HTML
<form class="wp-contact-form" method="post" action="">
  <div class="wp-form-row">
    <label for="cf-name">Your Name</label>
    <input type="text" id="cf-name" name="cf_name" required placeholder="John Smith">
  </div>
  <div class="wp-form-row">
    <label for="cf-phone">Phone Number</label>
    <input type="tel" id="cf-phone" name="cf_phone" required placeholder="(555) 555-5555">
  </div>
  <div class="wp-form-row">
    <label for="cf-email">Email Address</label>
    <input type="email" id="cf-email" name="cf_email" required placeholder="you@example.com">
  </div>
  <div class="wp-form-row">
    <label for="cf-message">How Can We Help?</label>
    <textarea id="cf-message" name="cf_message" rows="5" placeholder="Describe your project or question..."></textarea>
  </div>
  <div class="wp-form-row">
    <button type="submit" class="wp-btn-primary">Send Message</button>
  </div>
</form>
HTML;

    $emergency_section_widgets = [];
    if ($emergency) {
        $emergency_section_widgets = [
            webprinter_section('contact-emergency', [
                webprinter_column('contact-emrg-col', 100, [
                    webprinter_heading_widget('contact-emrg-h', '24/7 Emergency Service', 'h2'),
                    webprinter_text_widget('contact-emrg-body', "Emergencies don't wait. Call our emergency line any time."),
                    webprinter_button_widget('contact-emrg-btn', "Emergency: {$emrg_phone}", "tel:{$emrg_phone}"),
                ]),
            ], [
                'background_color' => '#c0392b',
                'color'            => '#ffffff',
                'padding'          => ['top' => '40', 'bottom' => '40'],
            ]),
        ];
    }

    $map_embed_html = "<div class='wp-map-placeholder' style='background:#e0e0e0;height:300px;display:flex;align-items:center;justify-content:center;'><p>Map — {$address}</p></div>";

    $template = [
        webprinter_section('contact-hero', [
            webprinter_column('contact-hero-col', 100, [
                webprinter_heading_widget('contact-h1', "Contact {$name}", 'h1'),
                webprinter_text_widget('contact-sub', "We'd love to hear from you. Reach out today and we'll respond promptly."),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'color'            => '#ffffff',
            'padding'          => ['top' => '80', 'bottom' => '80'],
        ]),
    ];

    foreach ($emergency_section_widgets as $s) {
        $template[] = $s;
    }

    $template[] = webprinter_section('contact-main', [
        webprinter_column('contact-form-col', 58, [
            webprinter_heading_widget('contact-form-h', 'Send Us a Message', 'h2'),
            webprinter_html_widget('contact-form', $contact_form_html),
        ]),
        webprinter_column('contact-info-col', 42, [
            webprinter_heading_widget('contact-info-h', 'Our Contact Info', 'h2'),
            webprinter_html_widget('contact-info-details', implode('', [
                "<p><strong>Phone:</strong> <a href='tel:{$phone}'>{$phone}</a></p>",
                "<p><strong>Email:</strong> <a href='mailto:{$email}'>{$email}</a></p>",
                "<p><strong>Address:</strong> {$address}</p>",
                "<p><strong>Hours:</strong> {$hours}</p>",
            ])),
            webprinter_html_widget('contact-map', $map_embed_html),
        ]),
    ], ['padding' => ['top' => '60', 'bottom' => '60']]);

    $template[] = webprinter_section('contact-cta-bar', [
        webprinter_column('contact-cta-col', 100, [
            webprinter_heading_widget('contact-cta-h', "Prefer to Call?", 'h2'),
            webprinter_heading_widget('contact-cta-phone', $phone, 'h2'),
            webprinter_button_widget('contact-cta-btn', "Call Now", "tel:{$phone}"),
        ]),
    ], [
        'background_color' => '#f0f4f8',
        'padding'          => ['top' => '50', 'bottom' => '50'],
    ]);

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
