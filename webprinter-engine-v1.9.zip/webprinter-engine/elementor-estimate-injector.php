<?php
/**
 * Elementor Estimate / InstaBid Page Injector
 *
 * Injects contractor data into the Estimate page Elementor template.
 * Supports an optional InstaBid embed code block.
 *
 * Exported functions:
 *   inject_estimate_data( array|null $template, array $data ) : array
 *   build_estimate_elementor_json( array $data )              : string  (used by plugin)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

require_once __DIR__ . '/elementor-header-footer-injector.php';

function inject_estimate_data($template, array $data) {
    if (empty($template)) {
        return json_decode(build_estimate_elementor_json($data), true);
    }

    $replacements = [
        '{{COMPANY_NAME}}'    => $data['name']          ?? '',
        '{{PHONE}}'           => $data['phone']         ?? '',
        '{{INSTABID_EMBED}}'  => $data['instabid_embed'] ?? '<!-- INSTABID_EMBED_CODE_HERE -->',
        '{{RESPONSE_TIME}}'   => $data['response_time'] ?? '24 hours',
    ];

    $json = json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
    $json = str_replace(array_keys($replacements), array_values($replacements), $json);
    return json_decode($json, true);
}

function build_estimate_elementor_json(array $data) {
    $name          = $data['company_name'] ?? $data['name'] ?? '';
    $phone         = $data['phone']         ?? '';
    $city          = $data['city']          ?? '';
    $state         = $data['state']         ?? '';
    $instabid      = $data['instabid_embed'] ?? '<!-- InstaBid embed code will appear here -->';
    $response_time = $data['response_time'] ?? '24 hours';

    $trust_signals = $data['trust_signals'] ?? [
        'Licensed & Insured',
        'Free Estimates',
        'Fast Response',
        '100% Satisfaction Guaranteed',
    ];

    $faqs = $data['faqs'] ?? [
        ['q' => 'How quickly can you provide an estimate?', 'a' => "We typically respond within {$response_time}."],
        ['q' => 'Is the estimate free?',                   'a' => 'Yes, all our estimates are completely free with no obligation.'],
        ['q' => 'What areas do you serve?',                'a' => "We proudly serve {$city}, {$state} and surrounding communities."],
    ];

    $trust_html = '<ul class="wp-trust-signals">';
    foreach ($trust_signals as $signal) {
        $trust_html .= '<li>' . esc_html($signal) . '</li>';
    }
    $trust_html .= '</ul>';

    $faq_html = '<div class="wp-faq-list">';
    foreach ($faqs as $faq) {
        $q = esc_html($faq['q'] ?? '');
        $a = esc_html($faq['a'] ?? '');
        $faq_html .= "<div class='wp-faq-item'><h4>{$q}</h4><p>{$a}</p></div>";
    }
    $faq_html .= '</div>';

    $template = [
        webprinter_section('est-hero', [
            webprinter_column('est-hero-col', 100, [
                webprinter_heading_widget('est-h1', "Get Your Free Estimate", 'h1'),
                webprinter_text_widget('est-sub', "We'll respond within {$response_time}. No obligation, no pressure."),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'color'            => '#ffffff',
            'padding'          => ['top' => '80', 'bottom' => '80'],
        ]),

        webprinter_section('est-trust', [
            webprinter_column('est-trust-col', 100, [
                webprinter_html_widget('est-trust-html', $trust_html),
            ]),
        ], [
            'background_color' => '#f0f4f8',
            'padding'          => ['top' => '30', 'bottom' => '30'],
        ]),

        webprinter_section('est-form', [
            webprinter_column('est-form-col', 66, [
                webprinter_heading_widget('est-form-h', "Request an Estimate", 'h2'),
                webprinter_html_widget('est-instabid', $instabid),
            ]),
            webprinter_column('est-contact-col', 34, [
                webprinter_heading_widget('est-contact-h', "Prefer to Call?", 'h3'),
                webprinter_heading_widget('est-phone', $phone, 'h2'),
                webprinter_text_widget('est-hours', "Available Mon–Fri 8am–5pm"),
                webprinter_button_widget('est-call-btn', "Call Now: {$phone}", "tel:{$phone}"),
            ]),
        ], ['padding' => ['top' => '60', 'bottom' => '60']]),

        webprinter_section('est-faq', [
            webprinter_column('est-faq-col', 100, [
                webprinter_heading_widget('est-faq-h', "Frequently Asked Questions", 'h2'),
                webprinter_html_widget('est-faq-html', $faq_html),
            ]),
        ], [
            'background_color' => '#f5f5f5',
            'padding'          => ['top' => '60', 'bottom' => '60'],
        ]),

        webprinter_section('est-cta-bar', [
            webprinter_column('est-cta-col', 100, [
                webprinter_heading_widget('est-cta-h', "Ready to Get Started?", 'h2'),
                webprinter_text_widget('est-cta-body', "{$name} is standing by to help you in {$city}, {$state}."),
                webprinter_button_widget('est-cta-btn', 'Submit Estimate Request', '#est-form'),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'color'            => '#ffffff',
            'padding'          => ['top' => '60', 'bottom' => '60'],
        ]),
    ];

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
