<?php
/**
 * Plugin Name: WebPrinter Engine
 * Plugin URI:  https://webprinter.io
 * Description: Contractor website generator. Exposes a REST endpoint to build complete Elementor-based sites from contractor JSON data.
 * Version:     1.1.0
 * Author:      WebPrinter
 * License:     GPL-2.0+
 *
 * @package WebPrinter
 */

defined('ABSPATH') || exit;

define('WEBPRINTER_DIR', plugin_dir_path(__FILE__));

require_once WEBPRINTER_DIR . 'elementor-header-footer-injector.php';
require_once WEBPRINTER_DIR . 'elementor-about-injector.php';
require_once WEBPRINTER_DIR . 'elementor-services-injector.php';
require_once WEBPRINTER_DIR . 'elementor-estimate-injector.php';
require_once WEBPRINTER_DIR . 'elementor-contact-injector.php';
require_once WEBPRINTER_DIR . 'contractor-schema-generator.php';

add_action('rest_api_init', 'webprinter_register_routes');

function webprinter_register_routes() {
    register_rest_route('webprinter/v1', '/generate', [
        'methods'             => 'POST',
        'callback'            => 'webprinter_handle_generate',
        'permission_callback' => 'webprinter_check_permission',
        'args'                => webprinter_route_args(),
    ]);
}

function webprinter_check_permission(WP_REST_Request $request) {
    $secret = get_option('webprinter_api_secret', '');
    if ($secret !== '') {
        $provided = $request->get_header('X-Webprinter-Secret');
        if ($provided !== $secret) {
            return new WP_Error('forbidden', 'Invalid API secret.', ['status' => 403]);
        }
    }
    return true;
}

function webprinter_route_args() {
    $str  = ['type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_text_field'];
    $html = ['type' => 'string', 'required' => false, 'sanitize_callback' => 'wp_kses_post'];
    $num  = ['type' => 'number', 'required' => false];
    $int  = ['type' => 'integer', 'required' => false];

    return [
        // Required
        'company_name'      => array_merge($str, ['required' => true]),
        'trade'             => array_merge($str, ['required' => true]),
        'city'              => array_merge($str, ['required' => true]),
        'state'             => array_merge($str, ['required' => true]),
        'phone'             => array_merge($str, ['required' => true]),
        // Optional — email no longer required (n8n often sends empty)
        'email'             => ['type' => 'string', 'required' => false, 'sanitize_callback' => 'sanitize_email'],
        // Identity
        'address'           => $str,
        'zip'               => $str,
        'website'           => $str,
        'logo_url'          => $str,
        'photo_url'         => $str,
        // Content
        'tagline'           => $str,
        'hero_headline'     => $str,
        'hero_sub'          => $str,
        'about'             => $html,
        'years_in_business' => $str,
        // Services — names AND descriptions
        'service_1_name'    => $str,
        'service_1_desc'    => $str,
        'service_2_name'    => $str,
        'service_2_desc'    => $str,
        'service_3_name'    => $str,
        'service_3_desc'    => $str,
        'service_4_name'    => $str,
        'service_4_desc'    => $str,
        // Social proof
        'rating'            => $num,
        'review_count'      => $int,
        'testimonial_1'     => $str,
        'testimonial_2'     => $str,
        // Meta
        'hours'             => $str,
        'license'           => $str,
        'template'          => $str,
    ];
}

function webprinter_handle_generate(WP_REST_Request $request) {
    $p = $request->get_params();

    $company  = $p['company_name'];
    $trade    = $p['trade'];
    $city     = $p['city'];
    $state    = $p['state'];
    $phone    = $p['phone'];
    $email    = $p['email']             ?? '';
    $website  = $p['website']           ?? site_url();
    $tagline  = $p['tagline']           ?? "Professional {$trade} Services in {$city}";
    $headline = $p['hero_headline']     ?? "Trusted {$trade} Services in {$city}, {$state}";
    $hero_sub = $p['hero_sub']          ?? "Serving {$city}, {$state} and surrounding areas";
    $about    = $p['about']             ?? "We are {$company}, providing quality {$trade} services in {$city}.";
    $years    = $p['years_in_business'] ?? '';
    $address  = $p['address']           ?? "{$city}, {$state}";
    $logo_url = $p['logo_url']          ?? '';
    $photo_url = $p['photo_url']        ?? '';
    $rating      = $p['rating']       ?? 0;
    $review_count = $p['review_count'] ?? 0;
    $testimonial_1 = $p['testimonial_1'] ?? '';
    $testimonial_2 = $p['testimonial_2'] ?? '';

    // Build services array — use names from n8n, fall back to trade-based defaults
    $services = [
        [
            'name'        => $p['service_1_name'] ?? ucfirst($trade) . ' Installation',
            'description' => $p['service_1_desc'] ?? "Expert {$trade} installation for your home or business.",
        ],
        [
            'name'        => $p['service_2_name'] ?? ucfirst($trade) . ' Repair',
            'description' => $p['service_2_desc'] ?? "Fast, reliable {$trade} repairs at competitive prices.",
        ],
        [
            'name'        => $p['service_3_name'] ?? ucfirst($trade) . ' Maintenance',
            'description' => $p['service_3_desc'] ?? "Keep your {$trade} systems running smoothly year-round.",
        ],
        [
            'name'        => $p['service_4_name'] ?? 'Emergency Service',
            'description' => $p['service_4_desc'] ?? "24/7 emergency {$trade} response when you need it most.",
        ],
    ];

    // Fix site identity — populates footer company name and tagline
    update_option('blogname',        $company);
    update_option('blogdescription', $tagline);

    $base = [
        'company_name'      => $company,
        'name'              => $company,
        'trade'             => $trade,
        'city'              => $city,
        'state'             => $state,
        'phone'             => $phone,
        'email'             => $email,
        'website'           => $website,
        'address'           => $address,
        'tagline'           => $tagline,
        'hero_headline'     => $headline,
        'hero_sub'          => $hero_sub,
        'about'             => $about,
        'years_in_business' => $years,
        'logo_url'          => $logo_url,
        'photo_url'         => $photo_url,
        'rating'            => $rating,
        'review_count'      => $review_count,
        'testimonial_1'     => $testimonial_1,
        'testimonial_2'     => $testimonial_2,
        'services'          => $services,
    ];

    $schema_html = generate_contractor_schema([
        'name'    => $company,
        'trade'   => $trade,
        'phone'   => $phone,
        'email'   => $email,
        'address' => $address,
        'city'    => $city,
        'state'   => $state,
        'website' => $website,
        'services' => array_column($services, 'name'),
    ]);

    $pages_config = [
        'home' => [
            'title' => $company . ' - Home',
            'slug'  => 'front-page',
            'json'  => build_about_elementor_json(array_merge($base, [
                'hero_headline' => $headline,
                'hero_sub'      => $hero_sub,
            ])),
        ],
        'about' => [
            'title' => 'About ' . $company,
            'slug'  => 'about',
            'json'  => build_about_elementor_json($base),
        ],
        'services' => [
            'title' => $company . ' Services',
            'slug'  => 'services',
            'json'  => build_services_elementor_json($base),
        ],
        'estimate' => [
            'title' => 'Get a Free Estimate',
            'slug'  => 'estimate',
            'json'  => build_estimate_elementor_json($base),
        ],
        'contact' => [
            'title' => 'Contact ' . $company,
            'slug'  => 'contact',
            'json'  => build_contact_elementor_json($base),
        ],
    ];

    $urls    = [];
    $page_ids = [];

    foreach ($pages_config as $key => $cfg) {
        // Step 1: Create the bare page first — no Elementor data yet
        $post_id = webprinter_upsert_page($cfg['title'], $cfg['slug']);

        if (is_wp_error($post_id)) {
            $err_msg = $post_id->get_error_message();
            return new WP_Error('page_create_failed', "Failed to create page: {$cfg['slug']} — {$err_msg}", ['status' => 500]);
        }

        // Step 2: Set Elementor mode flags via update_post_meta (these are safe)
        update_post_meta($post_id, '_elementor_edit_mode',     'builder');
        update_post_meta($post_id, '_elementor_template_type', 'wp-page');
        update_post_meta($post_id, '_elementor_version',       '3.0.0');

        // Step 3: Write _elementor_data directly via wpdb — bypasses Elementor permission hook
        global $wpdb;
        $json_data = $cfg['json'];
        $existing  = $wpdb->get_var( $wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta} WHERE post_id = %d AND meta_key = '_elementor_data' LIMIT 1",
            $post_id
        ));
        if ( $existing ) {
            $wpdb->update(
                $wpdb->postmeta,
                [ 'meta_value' => $json_data ],
                [ 'post_id' => $post_id, 'meta_key' => '_elementor_data' ],
                [ '%s' ],
                [ '%d', '%s' ]
            );
        } else {
            $wpdb->insert(
                $wpdb->postmeta,
                [ 'post_id' => $post_id, 'meta_key' => '_elementor_data', 'meta_value' => $json_data ],
                [ '%d', '%s', '%s' ]
            );
        }
        wp_cache_delete( $post_id, 'post_meta' );
        clean_post_cache( $post_id );

        if ($key === 'home') {
            update_post_meta($post_id, '_webprinter_schema', $schema_html);
            update_option('page_on_front', $post_id);
            update_option('show_on_front', 'page');
        }

        $urls[$key]     = get_permalink($post_id);
        $page_ids[$key] = $post_id;
    }

    // Wire nav menu so links actually work
    webprinter_build_nav_menu($page_ids, $company);

    // Replace placeholders in existing Elementor header/footer templates
    webprinter_replace_template_placeholders($base);

    return rest_ensure_response([
        'success' => true,
        'company' => $company,
        'urls'    => $urls,
    ]);
}

function webprinter_replace_template_placeholders(array $data) {
    global $wpdb;

    $company = $data['company_name'] ?? '';
    $phone   = $data['phone']        ?? '';
    $email   = $data['email']        ?? '';
    $tagline = $data['tagline']      ?? '';
    $city    = $data['city']         ?? '';
    $state   = $data['state']        ?? '';
    $address = $data['address']      ?? "{$city}, {$state}";

    // Bracket-style placeholders used in theme templates
    $search = [
        '[COMPANY NAME]', '[TAGLINE]', '[PHONE NUMBER]',
        '[EMAIL ADDRESS]', '[CITY, STATE]', '[ADDRESS]',
        '[TRADE]', '[CITY]', '[STATE]',
    ];
    $replace = [
        $company, $tagline, $phone,
        $email, "{$city}, {$state}", $address,
        $data['trade'] ?? '', $city, $state,
    ];

    // Find all Elementor library templates (headers/footers built with UAE/HFE)
    $template_post_types = [ 'elementor_library', 'uae-template', 'uael-template', 'ae_global_templates' ];
    $placeholders_in     = implode("','", array_map('esc_sql', $template_post_types));

    $template_ids = $wpdb->get_col(
        "SELECT ID FROM {$wpdb->posts}
         WHERE post_type IN ('{$placeholders_in}')
         AND post_status IN ('publish','draft')
         LIMIT 50"
    );

    // Also grab any post with _elementor_data containing our placeholder strings
    $like_ids = $wpdb->get_col(
        $wpdb->prepare(
            "SELECT DISTINCT post_id FROM {$wpdb->postmeta}
             WHERE meta_key = '_elementor_data'
             AND meta_value LIKE %s
             LIMIT 50",
            '%[COMPANY NAME]%'
        )
    );

    $all_ids = array_unique( array_merge( (array) $template_ids, (array) $like_ids ) );

    foreach ( $all_ids as $tid ) {
        $meta_id = $wpdb->get_var( $wpdb->prepare(
            "SELECT meta_id FROM {$wpdb->postmeta}
             WHERE post_id = %d AND meta_key = '_elementor_data' LIMIT 1",
            $tid
        ));
        if ( ! $meta_id ) continue;

        $current = $wpdb->get_var( $wpdb->prepare(
            "SELECT meta_value FROM {$wpdb->postmeta} WHERE meta_id = %d",
            $meta_id
        ));
        if ( ! $current ) continue;

        $updated = str_replace( $search, $replace, $current );
        if ( $updated === $current ) continue; // nothing changed

        $wpdb->update(
            $wpdb->postmeta,
            [ 'meta_value' => $updated ],
            [ 'meta_id' => $meta_id ],
            [ '%s' ],
            [ '%d' ]
        );
        wp_cache_delete( $tid, 'post_meta' );
        clean_post_cache( $tid );
    }
}

function webprinter_build_nav_menu(array $page_ids, string $company) {
    $menu_name = $company . ' Nav';
    $menu_id   = wp_create_nav_menu($menu_name);

    if (is_wp_error($menu_id)) {
        // Menu may already exist — find it
        $menu_obj = wp_get_nav_menu_object($menu_name);
        if ($menu_obj) {
            $menu_id = $menu_obj->term_id;
            // Clear existing items
            $items = wp_get_nav_menu_items($menu_id);
            if ($items) {
                foreach ($items as $item) {
                    wp_delete_post($item->ID, true);
                }
            }
        } else {
            return; // Can't create or find menu — skip
        }
    }

    $menu_items = [
        'Home'       => $page_ids['home']     ?? 0,
        'Services'   => $page_ids['services'] ?? 0,
        'About'      => $page_ids['about']    ?? 0,
        'Contact'    => $page_ids['contact']  ?? 0,
    ];

    $order = 1;
    foreach ($menu_items as $label => $page_id) {
        if (!$page_id) continue;
        wp_update_nav_menu_item($menu_id, 0, [
            'menu-item-title'     => $label,
            'menu-item-object'    => 'page',
            'menu-item-object-id' => $page_id,
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
            'menu-item-position'  => $order++,
        ]);
    }

    // Add GET QUOTE button
    if (!empty($page_ids['estimate'])) {
        wp_update_nav_menu_item($menu_id, 0, [
            'menu-item-title'     => 'GET QUOTE',
            'menu-item-object'    => 'page',
            'menu-item-object-id' => $page_ids['estimate'],
            'menu-item-type'      => 'post_type',
            'menu-item-status'    => 'publish',
            'menu-item-position'  => $order++,
        ]);
    }

    // Assign to all registered theme locations
    $locations = get_theme_mod('nav_menu_locations', []);
    foreach (array_keys($locations) as $location) {
        $locations[$location] = $menu_id;
    }
    set_theme_mod('nav_menu_locations', $locations);
}

function webprinter_upsert_page($title, $slug) {
    $existing = get_page_by_path($slug, OBJECT, 'page');

    $post_data = [
        'post_title'   => $title,
        'post_name'    => $slug,
        'post_status'  => 'publish',
        'post_type'    => 'page',
        'post_content' => '',
    ];

    if ($existing) {
        $post_data['ID'] = $existing->ID;
        return wp_update_post($post_data, true);
    }

    return wp_insert_post($post_data, true);
}
