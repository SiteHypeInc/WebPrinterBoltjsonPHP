<?php
/**
 * Elementor Services Page Injector
 *
 * Injects contractor data into the Services page Elementor template.
 *
 * Exported functions:
 *   inject_services_data( string|null $json, array $data ) : string
 *   build_services_elementor_json( array $data )           : string  (used by plugin)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

require_once __DIR__ . '/elementor-header-footer-injector.php';

function inject_services_data($json, array $data) {
    if (empty($json)) {
        return build_services_elementor_json($data);
    }

    $services_html = '';
    foreach ($data['services'] ?? [] as $service) {
        $sname = esc_html($service['name']        ?? '');
        $sdesc = esc_html($service['description'] ?? '');
        $services_html .= "<div class='wp-service-card'><h3>{$sname}</h3><p>{$sdesc}</p></div>";
    }

    $areas_list = implode(', ', $data['service_areas'] ?? []);

    $replacements = [
        '{{COMPANY_NAME}}'  => $data['name']    ?? '',
        '{{TRADE}}'         => $data['trade']   ?? '',
        '{{TAGLINE}}'       => $data['tagline'] ?? '',
        '{{SERVICES_HTML}}' => $services_html,
        '{{SERVICE_AREAS}}' => $areas_list,
    ];

    return str_replace(array_keys($replacements), array_values($replacements), $json);
}

function build_services_elementor_json(array $data) {
    $name     = $data['company_name'] ?? $data['name'] ?? '';
    $trade    = ucfirst($data['trade']    ?? 'Contractor');
    $tagline  = $data['tagline']  ?? "Professional {$trade} Services";
    $city     = $data['city']     ?? '';
    $state    = $data['state']    ?? '';
    $phone    = $data['phone']    ?? '';
    $services = $data['services'] ?? [];

    $service_columns = [];
    $chunk_size = 2;
    $service_rows = array_chunk($services, $chunk_size);

    foreach ($service_rows as $row_index => $row) {
        $columns = [];
        $col_width = intval(100 / count($row));
        foreach ($row as $col_index => $service) {
            $sname = $service['name']        ?? "Service " . ($col_index + 1);
            $sdesc = $service['description'] ?? '';
            $col_id = "svc-row{$row_index}-col{$col_index}";
            $columns[] = webprinter_column($col_id, $col_width, [
                webprinter_heading_widget("{$col_id}-h", $sname, 'h3'),
                webprinter_text_widget("{$col_id}-body", $sdesc),
                webprinter_button_widget("{$col_id}-btn", 'Learn More', '/contact'),
            ]);
        }
        $service_columns[] = webprinter_section("svc-row-{$row_index}", $columns, [
            'padding' => ['top' => '30', 'bottom' => '30'],
        ]);
    }

    $area_list = implode(' &bull; ', $data['service_areas'] ?? [$city]);

    $template = [
        webprinter_section('svc-hero', [
            webprinter_column('svc-hero-col', 100, [
                webprinter_heading_widget('svc-h1', "{$trade} Services", 'h1'),
                webprinter_text_widget('svc-sub', $tagline),
                webprinter_button_widget('svc-cta', 'Get a Free Estimate', '/estimate'),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'color'            => '#ffffff',
            'padding'          => ['top' => '80', 'bottom' => '80'],
        ]),

        webprinter_section('svc-intro', [
            webprinter_column('svc-intro-col', 100, [
                webprinter_heading_widget('svc-intro-h', "What We Offer", 'h2'),
                webprinter_text_widget('svc-intro-body', "{$name} provides comprehensive {$trade} services to homes and businesses throughout {$city}, {$state}."),
            ]),
        ], ['padding' => ['top' => '50', 'bottom' => '30']]),
    ];

    foreach ($service_columns as $row) {
        $template[] = $row;
    }

    $template[] = webprinter_section('svc-areas', [
        webprinter_column('svc-areas-col', 100, [
            webprinter_heading_widget('svc-areas-h', 'Service Areas', 'h2'),
            webprinter_text_widget('svc-areas-body', "We proudly serve: {$area_list}"),
        ]),
    ], [
        'background_color' => '#f5f5f5',
        'padding'          => ['top' => '50', 'bottom' => '50'],
    ]);

    $template[] = webprinter_section('svc-cta-bar', [
        webprinter_column('svc-cta-col', 100, [
            webprinter_heading_widget('svc-cta-h', "Contact {$name} Today", 'h2'),
            webprinter_text_widget('svc-cta-body', "Call us at {$phone} or request a free estimate online."),
            webprinter_button_widget('svc-cta-btn', 'Get a Free Estimate', '/estimate'),
            webprinter_button_widget('svc-call-btn', "Call {$phone}", "tel:{$phone}"),
        ]),
    ], [
        'background_color' => '#1a3a5c',
        'color'            => '#ffffff',
        'padding'          => ['top' => '60', 'bottom' => '60'],
    ]);

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
