<?php
/**
 * Elementor About Page Injector
 *
 * Injects contractor data into the About page Elementor template.
 *
 * Exported functions:
 *   inject_about_data( string|null $json, array $data ) : string
 *   build_about_elementor_json( array $data )           : string  (used by plugin)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

require_once __DIR__ . '/elementor-header-footer-injector.php';

function inject_about_data($json, array $data) {
    if (empty($json)) {
        return build_about_elementor_json($data);
    }

    $replacements = [
        '{{COMPANY_NAME}}'    => $data['name']             ?? '',
        '{{HERO_HEADLINE}}'   => $data['hero_headline']    ?? '',
        '{{HERO_SUB}}'        => $data['hero_sub']         ?? '',
        '{{ABOUT_TEXT}}'      => $data['about']            ?? '',
        '{{YEARS_IN_BIZ}}'    => $data['years_in_business'] ?? '',
        '{{PHONE}}'           => $data['phone']            ?? '',
        '{{ADDRESS}}'         => $data['address']          ?? '',
    ];

    return str_replace(array_keys($replacements), array_values($replacements), $json);
}

function build_about_elementor_json(array $data) {
    $name    = $data['company_name'] ?? $data['name'] ?? '';
    $phone   = $data['phone']   ?? '';
    $city    = $data['city']    ?? '';
    $state   = $data['state']   ?? '';
    $about   = $data['about']   ?? "We are {$name}, proudly serving {$city}, {$state} with quality service.";
    $tagline = $data['tagline'] ?? '';
    $years   = $data['years_in_business'] ?? 10;
    $headline = $data['hero_headline'] ?? "About {$name}";
    $sub      = $data['hero_sub']     ?? "Experience. Quality. Trust.";

    $template = [
        webprinter_section('about-hero', [
            webprinter_column('about-hero-col', 100, [
                webprinter_heading_widget('about-h1', $headline, 'h1'),
                webprinter_text_widget('about-sub', $sub),
                webprinter_button_widget('about-cta', 'Get a Free Estimate', '/estimate'),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'padding'          => ['top' => '80', 'bottom' => '80'],
            'color'            => '#ffffff',
        ]),

        webprinter_section('about-story', [
            webprinter_column('about-story-col', 60, [
                webprinter_heading_widget('about-story-h', "Our Story", 'h2'),
                webprinter_text_widget('about-story-body', $about),
            ]),
            webprinter_column('about-stats-col', 40, [
                webprinter_heading_widget('about-yib-h', "{$years}+", 'h2'),
                webprinter_text_widget('about-yib-label', 'Years in Business'),
                webprinter_heading_widget('about-phone-h', $phone, 'h3'),
                webprinter_text_widget('about-phone-label', "Call us today"),
                webprinter_button_widget('about-phone-btn', "Call {$phone}", "tel:{$phone}"),
            ]),
        ], ['padding' => ['top' => '60', 'bottom' => '60']]),

        webprinter_section('about-values', [
            webprinter_column('about-val-1', 33, [
                webprinter_heading_widget('about-val-1-h', 'Quality Work', 'h3'),
                webprinter_text_widget('about-val-1-body', "We take pride in delivering the highest quality workmanship on every project."),
            ]),
            webprinter_column('about-val-2', 33, [
                webprinter_heading_widget('about-val-2-h', 'Reliable Service', 'h3'),
                webprinter_text_widget('about-val-2-body', "You can count on us to show up on time and get the job done right."),
            ]),
            webprinter_column('about-val-3', 33, [
                webprinter_heading_widget('about-val-3-h', 'Fair Pricing', 'h3'),
                webprinter_text_widget('about-val-3-body', "Transparent pricing with no hidden fees — we earn your trust every step of the way."),
            ]),
        ], [
            'background_color' => '#f5f5f5',
            'padding'          => ['top' => '60', 'bottom' => '60'],
        ]),

        webprinter_section('about-cta-bar', [
            webprinter_column('about-cta-col', 100, [
                webprinter_heading_widget('about-cta-h', "Ready to Get Started?", 'h2'),
                webprinter_text_widget('about-cta-body', "Contact {$name} today for a free estimate. Serving {$city}, {$state} and surrounding areas."),
                webprinter_button_widget('about-cta-btn', 'Get a Free Estimate', '/estimate'),
            ]),
        ], [
            'background_color' => '#1a3a5c',
            'color'            => '#ffffff',
            'padding'          => ['top' => '60', 'bottom' => '60'],
        ]),
    ];

    return json_encode($template, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
}
