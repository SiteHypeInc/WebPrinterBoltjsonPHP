<?php
/**
 * Contractor Schema Generator
 *
 * Generates LocalBusiness JSON-LD schema markup and Open Graph / Twitter
 * meta tags for a contractor website.
 *
 * Exported functions:
 *   generate_contractor_schema( array $data ) : string   (JSON-LD <script> tag)
 *   generate_meta_tags( array $data )         : string   (HTML <meta> tags)
 *
 * @package WebPrinter
 */

defined('ABSPATH') || define('ABSPATH', dirname(__DIR__) . '/');

function generate_contractor_schema(array $data) {
    $name    = $data['name']    ?? '';
    $phone   = $data['phone']   ?? '';
    $email   = $data['email']   ?? '';
    $website = $data['website'] ?? '';
    $logo    = $data['logo']    ?? '';
    $trade   = strtolower($data['trade'] ?? 'contractor');
    $city    = $data['city']    ?? '';
    $state   = $data['state']   ?? '';
    $zip     = $data['zip']     ?? '';
    $street  = $data['address'] ?? '';

    $type_map = [
        'hvac'              => 'HVACBusiness',
        'plumbing'          => 'Plumber',
        'electrical'        => 'Electrician',
        'roofing'           => 'RoofingContractor',
        'painting'          => 'PaintingContractor',
        'landscaping'       => 'LandscapingBusiness',
        'carpentry'         => 'GeneralContractor',
        'locksmith'         => 'Locksmith',
        'general_contractor' => 'GeneralContractor',
        'pest_control'      => 'PestControlBusiness',
    ];

    $schema_type = $type_map[$trade] ?? 'LocalBusiness';

    $schema = [
        '@context' => 'https://schema.org',
        '@type'    => $schema_type,
        'name'     => $name,
        'url'      => $website,
        'telephone' => $phone,
        'email'    => $email,
        'address'  => [
            '@type'           => 'PostalAddress',
            'streetAddress'   => $street,
            'addressLocality' => $city,
            'addressRegion'   => $state,
            'postalCode'      => $zip,
            'addressCountry'  => 'US',
        ],
    ];

    if (!empty($logo)) {
        $schema['logo'] = $logo;
        $schema['image'] = $logo;
    }

    if (!empty($data['lat']) && !empty($data['lng'])) {
        $schema['geo'] = [
            '@type'     => 'GeoCoordinates',
            'latitude'  => $data['lat'],
            'longitude' => $data['lng'],
        ];
    }

    if (!empty($data['rating']) && !empty($data['review_count'])) {
        $schema['aggregateRating'] = [
            '@type'       => 'AggregateRating',
            'ratingValue' => number_format((float) $data['rating'], 1),
            'reviewCount' => (int) $data['review_count'],
        ];
    }

    if (!empty($data['services']) && is_array($data['services'])) {
        $schema['hasOfferCatalog'] = [
            '@type' => 'OfferCatalog',
            'name'  => "{$name} Services",
            'itemListElement' => array_map(function ($service, $i) {
                return [
                    '@type'    => 'Offer',
                    'position' => $i + 1,
                    'name'     => is_array($service) ? ($service['name'] ?? $service) : $service,
                ];
            }, $data['services'], array_keys($data['services'])),
        ];
    }

    if (!empty($data['service_areas']) && is_array($data['service_areas'])) {
        $schema['areaServed'] = array_map(function ($area) {
            return ['@type' => 'City', 'name' => $area];
        }, $data['service_areas']);
    }

    if (!empty($data['hours'])) {
        $schema['openingHours'] = $data['hours'];
    }

    if (!empty($data['price_range'])) {
        $schema['priceRange'] = $data['price_range'];
    }

    if (!empty($data['social_urls']) && is_array($data['social_urls'])) {
        $valid_urls = array_filter($data['social_urls']);
        if (!empty($valid_urls)) {
            $schema['sameAs'] = array_values($valid_urls);
        }
    }

    $json = json_encode($schema, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE | JSON_PRETTY_PRINT);
    return "<script type=\"application/ld+json\">\n{$json}\n</script>";
}

function generate_meta_tags(array $data) {
    $name    = htmlspecialchars($data['name']    ?? '', ENT_QUOTES);
    $trade   = htmlspecialchars(ucfirst($data['trade'] ?? 'contractor'), ENT_QUOTES);
    $city    = htmlspecialchars($data['city']    ?? '', ENT_QUOTES);
    $state   = htmlspecialchars($data['state']   ?? '', ENT_QUOTES);
    $phone   = htmlspecialchars($data['phone']   ?? '', ENT_QUOTES);
    $website = htmlspecialchars($data['website'] ?? '', ENT_QUOTES);
    $logo    = htmlspecialchars($data['logo']    ?? '', ENT_QUOTES);

    $title       = "{$name} | {$trade} Services in {$city}, {$state}";
    $description = "Looking for a trusted {$trade} in {$city}, {$state}? {$name} offers professional services at competitive rates. Call {$phone} today for a free estimate.";

    $tags = [
        "<meta name=\"description\"        content=\"{$description}\">",
        "<meta name=\"robots\"             content=\"index, follow\">",

        "<meta property=\"og:type\"        content=\"business.business\">",
        "<meta property=\"og:title\"       content=\"{$title}\">",
        "<meta property=\"og:description\" content=\"{$description}\">",
        "<meta property=\"og:url\"         content=\"{$website}\">",

        "<meta name=\"twitter:card\"        content=\"summary_large_image\">",
        "<meta name=\"twitter:title\"       content=\"{$title}\">",
        "<meta name=\"twitter:description\" content=\"{$description}\">",

        "<meta name=\"geo.region\"    content=\"US-{$state}\">",
        "<meta name=\"geo.placename\" content=\"{$city}\">",

        "<link rel=\"canonical\" href=\"{$website}\">",
    ];

    if (!empty($logo)) {
        $tags[] = "<meta property=\"og:image\"         content=\"{$logo}\">";
        $tags[] = "<meta name=\"twitter:image\"        content=\"{$logo}\">";
    }

    return implode("\n", $tags);
}
